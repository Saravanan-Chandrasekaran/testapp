import React from "react";
import Switch from "./Switch";
import 'font-awesome/css/font-awesome.min.css'

export default function Header(props) {
    return <div className="header">
        <div> VIKI </div>
		<div>
		{!props.value && <div onClick={()=>{props.setValue(!props.value)}} style={{display:'inline', marginRight:'10px'}}> <i className="fa fa-bell fa-lg"></i></div>}
			<div style={{display:'inline'}}> <i className="fa fa-times-circle fa-lg" ></i></div>
		</div>
		
    </div>;
}
