import React, { useEffect, useRef } from "react";
import 'font-awesome/css/font-awesome.min.css'
export default function CurbSideAlerts({ messages }) {
    const el = useRef(null);
    useEffect(() => {
        el.current.scrollIntoView({ block: "end", behavior: "smooth" });
    });
    return (
        <div className="messages">
		{messages}
            <div id={"el"} ref={el} />
        </div>
    );
}
