import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom";
import airpods from './assets/airpods.PNG'
import magsafe from './assets/magsafe.PNG'
import posbg from './assets/pos-bg.PNG'
import airtag from './assets/airtag.PNG'
import watch from './assets/appleWatch.PNG'
import BotMessage from "./components/BotMessage";
import BotAlert from "./components/BotAlert";
import UserMessage from "./components/UserMessage";
import Messages from "./components/Messages";
import CurbSideAlerts from "./components/CurbSideAlerts";
import Input from "./components/Input";
// import io from "socket.io-client";
import API from "./ChatbotAPI";
import 'font-awesome/css/font-awesome.min.css'
import "./styles.css";
import Header from "./components/Header";



const MINUTE_MS = 3000;

// http://45.76.50.120:8080/sms?ToCountry=US&ToState=IL&SmsMessageSid=SM2b7e12487aeca472aeca68cd26601d50&NumMedia=0&ToCity=ROSELLE&FromZip=&SmsSid=SM2b7e12487aeca472aeca68cd26601d50&FromState=Chennai&SmsStatus=received&FromCity=&Body=Hi,+this+is+testing+&FromCountry=IN&To=%2B18475652097&ToZip=60193&NumSegments=1&MessageSid=SM2b7e12487aeca472aeca68cd26601d50&AccountSid=AC7b543f84226e7969e4d075d0b4a12c16&From=%2B919940073608&ApiVersion=2010-04-01


// let endPoint = "http://45.76.50.120:8080";
// let socket = io.connect(`${endPoint}`);

function Chatbot() {
  const [messages, setMessages] = useState([]);
  const [alerts, setAlerts] = useState(false);

  useEffect(() => {
	setMessages([
	  <BotMessage
		key={Math.random()}
		fetchMessage="Welcome to VIKI!"
	  />
	]);
	 getMessages();
  }, []);

  const getMessages = () => {
	  
	  const interval = setInterval(async () => {
		console.log('Logs every minute');

		const fetchMsg = async () => await API.getPollMessage();
		  let msg = await fetchMsg()
		  // console.log("pinting response msg")
		  // console.log(msg)
		  if(msg.message !== ""){
			  let ressppp = (
				<div>
				  <div>(562) 217-2914 : Sal Fragale</div>
				  <hr />
				  <div>{msg.message}
				  </div>
				</div>
			  )
			  setMessages(messages => messages.concat(<BotMessage
				key={Math.random()}
				fetchMessage={ressppp}
			  />));
		  }
		  
	  
	  }, MINUTE_MS);
	  
	  
	// socket.on("message", msg => {
	  //   let allMessages = messages;
	  //   allMessages.push(msg);
	  //   setMessages(allMessages);
	  // let ressppp = (
		// <div>
		  // <div>(904) 227-7994 : Rep Assist Bot</div>
		  // <hr />
		  // <div>{msg}
		  // </div>
		// </div>
	  // )
	  // setMessages([...messages, <BotMessage
		// key="0"
		// fetchMessage={ressppp}
	  // />]);
	// });
  };




  const sendPromoA = (
     <div>
		<div className='rootCnt'>
		  <b>Alex A</b> has purchased Apple iPhone 12 pro.<br/>
		  <b>Order Num:</b> 6548545<br/>
		  <b>MDN:</b>(562) 217-2914
		
		  <br/><hr/> <br/>
		  Below are some recommended accessories that your customer might be interested to purchase
		  <div className="detailsCont">
			<div className="detailsTitle">
			  
			  
				<div class="checkbox-container">
				  <input type="checkbox" id="linux"/>
				  <label class="checkbox" for="linux">Airpods with charging Case</label>
				</div>
			</div>
			<div className="detailCont">
			  <div >
				<img src={airpods} className="promoImg" />
			  </div>
			  <div className="promoDeatils">
				<div>
				  <span>Retail Price: </span>
				  <span>$159.99</span>
				</div>
				<div>
				
				  <span>Current Promotion: </span>
				  <span>$30 off</span>
				  </div>
				<div>
				  <span>Effective Date: </span>
				  <span>8/1/21 - 8/31/21</span>
				</div>
			  </div>
			</div>
		  </div>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send offer via SMS - airpods") }}>Send to customer</button>
		  </div>
		</div>
		<hr/>
		<div className='rootCnt'>
		  <div className="detailsCont">
			<div className="detailsTitle">
			  
			  
				<div class="checkbox-container">
				  <input type="checkbox" id="watchseries"/>
				  <label class="checkbox" for="watchseries">Apple Watch Series 6</label>
				</div>
			</div>
			<div className="detailCont">
			  <div >
				<img src={watch} className="promoImg" />
			  </div>
			  <div className="promoDeatils">
				<div>
				  <span>Retail Price: </span>
				  <span>$324.98</span>
				</div>
				
				<div>
				
				  <span>Current Promotion: </span>
				  <span>$55 off</span>
				  </div>
				<div>
				  <span>Effective Date: </span>
				<span>8/1/21 - 8/31/21</span>
				</div>
			  </div>
			</div>
		  </div>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send offer via SMS - appleWatch") }}>Send to customer</button>
		  </div>
		</div>
		<hr/>
		<div className='rootCnt'>
		  <div className="detailsCont">
			<div className="detailsTitle">
			  
			  
				<div class="checkbox-container">
				  <input type="checkbox" id="magsafecharger"/>
				  <label class="checkbox" for="magsafecharger">Magsafe Charger</label>
				</div>
			</div>
			<div className="detailCont">
			  <div >
				<img src={magsafe} className="promoImg" />
			  </div>
			  <div className="promoDeatils">
				
				<div>
				  <span>Retail Price: </span>
				  <span>$39.97</span>
				</div>
				
				<div>
				
				  <span>Current Promotion: </span>
				  <span>$10 off</span>
				  </div>
				<div>
				  <span>Effective Date: </span>
				  <span>8/1/21 - 8/31/21</span>
				</div>
			  </div>
			</div>
		  </div>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send offer via SMS - magsafe") }}>Send to customer</button>
		  </div>
		</div>
		<hr/>
		<div className='rootCnt'>
		  <div className="detailsCont">
			<div className="detailsTitle">
			
			  
				<div class="checkbox-container">
				  <input type="checkbox" id="aairtag"/>
				  <label class="checkbox" for="aairtag">Airtag</label>
				</div>
			  
			</div>
			<div className="detailCont">
			  <div >
				<img src={airtag} className="promoImg" />
			  </div>
			  <div className="promoDeatils">
				<div>
				  <span>Retail Price: </span>
				  <span>$29.97</span>
				</div>
				
				<div>
				
				  <span>Current Promotion: </span>
				  <span>$5 off</span>
				  </div>
				<div>
				  <span>Effective Date: </span>
				 <span>8/1/21 - 8/31/21</span>
				</div>
			  </div>
			</div>
		  </div>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send offer via SMS - airtag") }}>Send to customer</button>
		  </div>
		  <br/>
		  <br/>
		  <hr/>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send all items") }}>Send all items</button>
		  </div>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send selected items") }}>Send selected items</button>
		  </div>
		  <br/>
		</div>
	</div>
  )


  const sendPromoC = (
     <div>
		<div className='rootCnt'>
		  <b>Casey Huber</b> has purchased Apple iPhone 12 mini.<br/>
		  <b>Order Num:</b> 3453456<br/>
		  <b>MDN:</b>(562) 217-2914
		
		  <br/><hr/> <br/>
		  Below are some recommended accessories that your customer might be interested to purchase
		  <div className="detailsCont">
			<div className="detailsTitle">
			  
			  
				<div class="checkbox-container">
				  <input type="checkbox" id="linux"/>
				  <label class="checkbox" for="linux">Airpods with charging Case</label>
				</div>
			</div>
			<div className="detailCont">
			  <div >
				<img src={airpods} className="promoImg" />
			  </div>
			  <div className="promoDeatils">
				<div>
				  <span>Retail Price: </span>
				  <span>$159.99</span>
				</div>
				<div>
				
				  <span>Current Promotion: </span>
				  <span>$30 off</span>
				  </div>
				<div>
				  <span>Effective Date: </span>
				  <span>8/1/21 - 8/31/21</span>
				</div>
			  </div>
			</div>
		  </div>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send offer via SMS - airpods") }}>Send to customer</button>
		  </div>
		</div>
		<hr/>
		<div className='rootCnt'>
		  <div className="detailsCont">
			<div className="detailsTitle">
			  
			  
				<div class="checkbox-container">
				  <input type="checkbox" id="watchseries"/>
				  <label class="checkbox" for="watchseries">Apple Watch Series 6</label>
				</div>
			</div>
			<div className="detailCont">
			  <div >
				<img src={watch} className="promoImg" />
			  </div>
			  <div className="promoDeatils">
				<div>
				  <span>Retail Price: </span>
				  <span>$324.98</span>
				</div>
				
				<div>
				
				  <span>Current Promotion: </span>
				  <span>$55 off</span>
				  </div>
				<div>
				  <span>Effective Date: </span>
				<span>8/1/21 - 8/31/21</span>
				</div>
			  </div>
			</div>
		  </div>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send offer via SMS - appleWatch") }}>Send to customer</button>
		  </div>
		</div>
		<hr/>
		<div className='rootCnt'>
		  <div className="detailsCont">
			<div className="detailsTitle">
			  
			  
				<div class="checkbox-container">
				  <input type="checkbox" id="magsafecharger"/>
				  <label class="checkbox" for="magsafecharger">Magsafe Charger</label>
				</div>
			</div>
			<div className="detailCont">
			  <div >
				<img src={magsafe} className="promoImg" />
			  </div>
			  <div className="promoDeatils">
				
				<div>
				  <span>Retail Price: </span>
				  <span>$39.97</span>
				</div>
				
				<div>
				
				  <span>Current Promotion: </span>
				  <span>$10 off</span>
				  </div>
				<div>
				  <span>Effective Date: </span>
				  <span>8/1/21 - 8/31/21</span>
				</div>
			  </div>
			</div>
		  </div>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send offer via SMS - magsafe") }}>Send to customer</button>
		  </div>
		</div>
		<hr/>
		<div className='rootCnt'>
		  <div className="detailsCont">
			<div className="detailsTitle">
			
			  
				<div class="checkbox-container">
				  <input type="checkbox" id="aairtag"/>
				  <label class="checkbox" for="aairtag">Airtag</label>
				</div>
			  
			</div>
			<div className="detailCont">
			  <div >
				<img src={airtag} className="promoImg" />
			  </div>
			  <div className="promoDeatils">
				<div>
				  <span>Retail Price: </span>
				  <span>$29.97</span>
				</div>
				
				<div>
				
				  <span>Current Promotion: </span>
				  <span>$5 off</span>
				  </div>
				<div>
				  <span>Effective Date: </span>
				 <span>8/1/21 - 8/31/21</span>
				</div>
			  </div>
			</div>
		  </div>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send offer via SMS - airtag") }}>Send to customer</button>
		  </div>
		  <br/>
		  <br/>
		  <hr/>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send all items") }}>Send all items</button>
		  </div>
		  <div className="detailBtnCnt">
			<button className="detailBtn" onClick={() => { send("send selected items") }}>Send selected items</button>
		  </div>
		  <br/>
		</div>
	</div>
  )

  const sendOfferAirpod = (
	<div className='rootCnt'>
	  Success! Below accessory has been sent to the MDN (562) 217-2914
	  <div className="detailsCont">
		<div className="detailsTitle">
		  AirPods - $30 off
		</div>
		<div className="detailCont">
		  <div >
			<img src={airpods} className="promoImg" />
		  </div>
		  <div className="promoDeatils">
			<div>Get 30% off on Airpods. Offer effective till August 31st.</div>
		  </div>
		</div>
	  </div>
	  <div className="detailBtnCnt">
		<button className="detailBtn" onClick={() => { send("Accessory of the month - $30 off AirPods. Get 30% off on Airpods. Offer effective till August 31st. check out the accessesory using the below link. Reply back to us if you are interested to purchase it. ") }}>click here</button>
	  </div>
	</div>
  )
  const sendOfferAirpodWatch = (
	<div className='rootCnt'>
	  Success! Below accessory has been sent to the MDN (562) 217-2914
	  <div className="detailsCont">
		<div className="detailsTitle">
		  Accessory of the month - $30 off Apple watch series 6
		</div>
		<div className="detailCont">
		  <div >
			<img src={watch} className="promoImg" />
		  </div>
		  <div className="promoDeatils">
			<div>Get 30% off on Apple Watch Series 6. Offer effective till August 31st.</div>
		  </div>
		</div>
	  </div>
	  <div className="detailBtnCnt">
		<button className="detailBtn" onClick={() => { send("Accessory of the month - $30 off Apple watch series 6. Get 30% off on Apple watch series 6. Offer effective till August 31st. check out the accessesory using the below link. Reply back to us if you are interested to purchase it. ") }}>click here</button>
	  </div>
	</div>
  )
  const sendOfferMagsafe = (
	<div className='rootCnt'>
	  Success! Below accessory has been sent to the MDN (562) 217-2914
	  <div className="detailsCont">
		<div className="detailsTitle">
		  Accessory of the month - $10 off Magsafe Charger
		</div>
		<div className="detailCont">
		  <div >
			<img src={magsafe} className="promoImg" />
		  </div>
		  <div className="promoDeatils">
			<div>Get 30% off on Magsafe Charger. Offer effective till August 31st.</div>
		  </div>
		</div>
	  </div>
	  <div className="detailBtnCnt">
		<button className="detailBtn" onClick={() => { send("Accessory of the month - $30 off Magsafe Charger. Get 10% off on Magsafe Charger. Offer effective till August 31st. check out the accessesory using the below link. Reply back to us if you are interested to purchase it. ") }}>click here</button>
	  </div>
	</div>
  )
  const sendOfferAirtag = (
	<div className='rootCnt'>
	  Success! Below accessory has been sent to the MDN (562) 217-2914
	  <div className="detailsCont">
		<div className="detailsTitle">
		  Accessory of the month - $5 off Airtag
		</div>
		<div className="detailCont">
		  <div >
			<img src={airtag} className="promoImg" />
		  </div>
		  <div className="promoDeatils">
			<div>Get 30% off on Airtag. Offer effective till August 31st.</div>
		  </div>
		</div>
	  </div>
	  <div className="detailBtnCnt">
		<button className="detailBtn" onClick={() => { send("Accessory of the month - $5 off Airtag. Get 30% off on Airtag. Offer effective till August 31st. check out the accessesory using the below link. Reply back to us if you are interested to purchase it. ") }}>click here</button>
		</div>
	</div>
  )

  const send = async text => {
	let msg;
	if (text == 'Send Related Accessesories') {
	  msg = sendPromoC

	  setMessages(messages=>messages.concat(
		<UserMessage key={Math.random()} text={text} />,
		<BotMessage
		  key={Math.random()}
		  fetchMessage={msg}
		/>
	  ));
	} else if (text == 'Send Related Accessesories  ') {
	  msg = sendPromoA

	  setMessages(messages=>messages.concat(
		<UserMessage key={Math.random()} text={text} />,
		<BotMessage
		  key={Math.random()}
		  fetchMessage={msg}
		/>
	  ));
	} else if (text.indexOf('send offer via SMS -')> -1) {
	  if (text.indexOf('magsafe') > -1){
	  msg = sendOfferMagsafe
	  }
	  if (text.indexOf('airtag') > -1){
	  msg = sendOfferAirtag
	  }
	  if (text.indexOf('airpods') > -1){
	  msg = sendOfferAirpod
	  }
	  if (text.indexOf('appleWatch') > -1){
	  msg = sendOfferAirpodWatch
	  }
	  console.log(messages)
	  console.log(messages.length)

	  setMessages(messages=>messages.concat(
		<UserMessage key={Math.random()} text={text} />,
		<BotMessage
		  key={Math.random()}
		  fetchMessage={msg}
		/>
	  ));
	} else if (text.indexOf('Accessory of the month - ')>-1) {
	  let respp = (
		<div>
		  <div>VIKI : (562) 217-2914</div>
		  <hr />
		  <div>{text}
		  </div>
		</div>
	  )
	  const newMessages = messages.concat(

		<UserMessage key={Math.random()} text={respp} />
	  );
	   setMessages(messages=>messages.concat(
		<UserMessage key={Math.random()} text={respp} />
	  ));
	  let msg_data_content = text
		let msg_data = { message: msg_data_content, to: '5622172914' }
	  const fetchMsg = async () => await API.GetChatbotResponse(msg_data)
	  msg = await fetchMsg()
	 
	} else {
	  console.log("in else")
	  console.log(messages)
	  console.log(messages.length)
	  // const fetchMsg = async () => await API.GetWelcomeText(text)
	  // msg = await fetchMsg()
	  let resppp = (
		<div>
		  <div>VIKI : (562) 217-2914</div>
		  <hr />
		  <div>{text}
		  </div>
		</div>
	  )

	  setMessages(messages=>messages.concat(
		<UserMessage key={Math.random()} text={resppp} />
	  ));
	  let msg_data = { message: text, to: '5622172914' }
	  const fetchMsg = async () => await API.GetChatbotResponse(msg_data)
	  msg = await fetchMsg()
	  // console.log("pinting response msg")
	  // console.log(msg)
	  
	}

	console.log(messages)
  };
  
  const alert1 = (
		<div style={{textAlign:"left"}}>
			<div style={{display:'flex', justifyContent:'space-around', alignItems:'center'}}>
				<div>
					<i className="fa fa-truck fa-lg"></i>
				</div>
				<div   style={{marginLeft:'12px'}}>
					<div>
					<div>
					Casey Huber has arrived for curbside pick up at Southlake store
					</div>
					</div>
					<div style={{margin:'2px 0 0 0'}}>
					ISPU | Fri Aug 13 2021 01:55 PM
					</div>
				</div>
			</div>
			<div style={{display:'flex', flexDirection:'column' , marginTop:'10px'}}>
				<div style={{display:'flex', flexDirection:'row', justifyContent:'space-between',margin:'2px'}}>
					<div>
					<b>Order Status:</b> ARRIVED
					</div>
					<div>
					<b>Order Num:</b> 3453456
					</div>
				</div>
				<div style={{display:'flex', flexDirection:'row', justifyContent:'space-between',margin:'2px'}}>
					<div>
					<b>Pickup Location:</b> Q339001
					</div>
					<div>
					<b>Order Location:</b>0027301
					</div>
				</div>
			</div>
			<div className="detailBtnCnt">
			<button className="detailBtn" onClick={()=>{setAlerts(false); send("Send Related Accessesories")}}>Send Related Accessesories</button>
			</div>
		</div>
  )
  
  const alert2 = (
		<div style={{textAlign:"left"}}>
			<div style={{display:'flex', justifyContent:'space-around', alignItems:'center'}}>
				<div>
					<i className="fa fa-truck fa-lg"></i>
				</div>
				<div>
					<div>
					<div >
					Alex A has arrived for curbside pick up at Atlantic store
					</div>
					</div>
					<div style={{margin:'2px 0 0 0'}}>
					ISPU | Fri Aug 13 2021 03:10 PM
					</div>
				</div>
			</div>
			<div style={{display:'flex', flexDirection:'column', marginTop:'10px'}}>
				<div style={{display:'flex', flexDirection:'row', justifyContent:'space-between',margin:'2px'}}>
					<div>
					<b>Order Status:</b> ARRIVED
					</div>
					<div>
					<b>Order Num:</b> 6548545
					</div>
				</div>
				<div style={{display:'flex', flexDirection:'row', justifyContent:'space-between',margin:'2px'}}>
					<div>
					<b>Pickup Location:</b> D335001
					</div>
					<div>
					<b>Order Location:</b> Q339001
					</div>
				</div>
			</div>
			<div className="detailBtnCnt">
			<button className="detailBtn" onClick={()=>{setAlerts(false); send("Send Related Accessesories  ")}}>Send Related Accessesories</button>
			</div>
		</div>
  )
  
  const curbSideMsgs = [
  <BotAlert style={{borderRadius:'revert',width:'91%'}}
		key={Math.random()}
		fetchMessage={alert1}
	  />,
	  <BotAlert
		key={Math.random()}
		fetchMessage={alert2}
	  />
  ]

  return (
	<div className="dispCont"> 
	<div className="pos">
	
	</div>
	  <div className="chatbot">
		<Header value={alerts} setValue={setAlerts} />
		{!alerts && <Messages messages={messages} />}
		{alerts && <CurbSideAlerts messages={curbSideMsgs} />}
		{!alerts &&<Input onSend={send} />}
	  </div>
	</div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<Chatbot />, rootElement);
