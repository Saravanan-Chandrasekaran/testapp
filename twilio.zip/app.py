from flask import Flask, request, Response, redirect, render_template
from twilio.twiml.messaging_response import MessagingResponse, Body, Media, Message
import json
from twilio.rest import Client
from flask_socketio import SocketIO, send
in_sentence = ''
app = Flask (__name__)


app.config['SECRET_KEY'] = 'mysecret'

socketIo = SocketIO(app, cors_allowed_origins="*")


class twilioservice:
@app.route ('/')
def hello_world():
return 'Hello World!'

@app.route ('/sendmessage', methods=["GET", "POST"])
def sendmessage():
data = request.get_json()
to = data['to']
in_sentence = data['message']

resp_ui = twilioservice.send_message_to_customer(to,in_sentence)
return resp_ui



def send_message_to_customer(to,in_sentence):
account_sid = 'AC7b543f84226e7969e4d075d0b4a12c16'
auth_token = 'e0fd5cfa78921ec22ee57abec3eec051'
client = Client(account_sid,auth_token)
message = client.messages.create(from_='+18475652097',to='+91'+to,body=in_sentence,media_url=['https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRCBx5z5-B9YKxVarpBlRKx1rrlyH4MLrhU0VwWP2HzHwgLiyM_1O0Y49TJTim9OgwpKss&usqp=CAU'])

         
print ("came to message")
print (message)
print (message.sid)
return "sent message"

@app.route("/sms", methods=['GET', 'POST'])
@socketIo.on("message")
def incoming_sms():
"""Send a dynamic reply to an incoming text message"""
# Get the message the user sent our Twilio number
body = request.values.get('Body', None)
print(body)
send(body, broadcast=True)
return ""


def stwiliomsg(sentence):
# account_sid = 'AC282cfcbbb04d8ba290117f399d20ebf5'
# auth_token = '568ac11058b2c8e1e6aac561568bb419'
account_sid = 'AC7b543f84226e7969e4d075d0b4a12c16'
auth_token = 'e0fd5cfa78921ec22ee57abec3eec051'
client = Client(account_sid,auth_token)
#message = client.messages.create(from_='+16179368399',to='+919940073608',body='Thanks for checking in! Our Representive will  be shortly out with your order')
#message = client.messages.create(from_='+16179368399',to='+15053132666',body='Thanks for checking in! Our Representive will  be shortly out with your order')

if sentence == "assist":
message = client.messages.create(from_='+18475652097',to='+919042277994',body='Thanks for using Verizon curbside pickup. We will be out shortly with your order.')
elif sentence == 'sndpromo':
twilioservice.sndpromo()
else:
message = client.messages.create(from_='+18475652097',to='+919042277994',body=sentence)
print (message.sid)

def stwilio_gif():
msg_body = "Please check out!"
media_link = "https://support.apple.com/library/content/dam/edam/applecare/images/en_US/ios13-iphone-11pro-airpods-pro-setup-animation-steps.gif"
msg = response.message(str(msg_body))
if media_link:
msg.media(media_link)
return HttpResponse(response)


@app.route("/mms", methods=['GET', 'POST'])
def sms_reply():
"""Respond to incoming calls with a simple text message."""
# Start our TwiML response
#number = request.form['From']
message_body = request.form['Body']
body = request.values.get('Body', None)
print (message_body)
resp = MessagingResponse()
print (resp)

# Code to send a plain text message
#resp.message("The Robots are coming! Head for the hills!")
msg = resp.message("The Robots are coming! Head for the hills!")
msg.media("https://farm8.staticflickr.com/7090/6941316406_80b4d6d50e_z_d.jpg")
#msg.media("https://support.apple.com/library/content/dam/edam/applecare/images/en_US/ios13-iphone-11pro-airpods-pro-setup-animation-steps.gif")
return str(resp)


def sndpromo():
"""Send the promo"""
message_body = request.form['Body']
#body = request.values.get('Body', None)
print (message_body)
resp = MessagingResponse()
msg = resp.message("Accessory of the Month - $30 off Airpods. Offer effective till August 25th")
msg.media("https://farm8.staticflickr.com/7090/6941316406_80b4d6d50e_z_d.jpg")
#msg.media("https://support.apple.com/library/content/dam/edam/applecare/images/en_US/ios13-iphone-11pro-airpods-pro-setup-animation-steps.gif")
return str(resp)

def assistconfirm(screen):
"""Send the promo"""
confirm_msg = ''
if screen == "assist":
confirm_msg = json.dumps({"text" : "The below message will be sent to the customer. Select confirm to send.", "cust_msg" : "Thanks for using Verizon curbside pickup. We will be out shortly with your order."})
else:
confirm_msg = json.dumps({"text" : "The below message will be sent to the customer. Select confirm to send.", "cust_msg" : "Thanks for using Verizon curbside pickup. We will be out shortly with your order."})
return confirm_msg




# if __name__ == "__main__":
# app.run(debug=True)


if __name__ == '__main__':
app.run(host='45.76.50.120', port=8080)

socketIo.run(app)
